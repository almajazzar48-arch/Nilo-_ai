import 'dart:convert';
import 'dart:io';

Future<void> main() async {
  final server = await HttpServer.bind(InternetAddress.anyIPv4, 8080);
  print('Nilo backend listening on port ${server.port}');

  await for (final request in server) {
    if (request.method == 'POST' && request.uri.path == '/chat') {
      try {
        final body = await utf8.decoder.bind(request).join();
        final data = jsonDecode(body) as Map<String, dynamic>;
        final message = data['message']?.toString() ?? '';

        // TODO: Connect this function to your chosen AI provider.
        // Keep the secret API key in an environment variable on the server.
        final reply = await generateReply(message);

        request.response
          ..headers.contentType = ContentType.json
          ..statusCode = HttpStatus.ok
          ..write(jsonEncode({'reply': reply}));
      } catch (e) {
        request.response
          ..headers.contentType = ContentType.json
          ..statusCode = HttpStatus.badRequest
          ..write(jsonEncode({'error': 'Invalid request'}));
      } finally {
        await request.response.close();
      }
    } else {
      request.response
        ..statusCode = HttpStatus.notFound
        ..write('Not found');
      await request.response.close();
    }
  }
}

Future<String> generateReply(String message) async {
  // Placeholder until an AI provider is configured.
  return 'استلمت رسالتك: $message\n\nالخادم شغال، وباقي ربط مزوّد الذكاء الاصطناعي بشكل آمن.';
}
