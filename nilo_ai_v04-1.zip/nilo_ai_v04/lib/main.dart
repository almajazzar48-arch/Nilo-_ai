import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const NiloApp());

class NiloApp extends StatelessWidget {
  const NiloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Nilo AI',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF7C5CFC),
        fontFamily: 'sans',
      ),
      home: const NiloHome(),
    );
  }
}

class ChatMessage {
  final String text;
  final bool fromUser;
  ChatMessage(this.text, this.fromUser);

  Map<String, dynamic> toJson() => {'text': text, 'fromUser': fromUser};
  factory ChatMessage.fromJson(Map<String, dynamic> j) =>
      ChatMessage(j['text'] ?? '', j['fromUser'] == true);
}

class NiloHome extends StatefulWidget {
  const NiloHome({super.key});

  @override
  State<NiloHome> createState() => _NiloHomeState();
}

class _NiloHomeState extends State<NiloHome> {
  final input = TextEditingController();
  final scroll = ScrollController();
  final tts = FlutterTts();
  final speech = stt.SpeechToText();

  final List<ChatMessage> messages = [
    ChatMessage('أهلًا! أنا نيلو 💜\nاحكيلي شو بدك وأنا بساعدك خطوة بخطوة.', false),
  ];

  bool listening = false;
  bool speaking = false;
  bool loading = false;
  bool voiceReplies = true;

  // Put your own backend URL here later.
  // Never put a private AI API key inside the Flutter app.
  static const backendUrl = 'https://YOUR-BACKEND.example.com/chat';

  @override
  void initState() {
    super.initState();
    _loadMessages();
    tts.setCompletionHandler(() {
      if (mounted) setState(() => speaking = false);
    });
  }

  Future<void> _loadMessages() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('nilo_messages');
    if (raw == null) return;
    final list = (jsonDecode(raw) as List)
        .map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    if (!mounted) return;
    setState(() {
      messages
        ..clear()
        ..addAll(list);
    });
  }

  Future<void> _saveMessages() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'nilo_messages',
      jsonEncode(messages.map((m) => m.toJson()).toList()),
    );
  }

  Future<void> _speak(String text) async {
    if (!voiceReplies) return;
    setState(() => speaking = true);
    await tts.setLanguage('ar');
    await tts.setSpeechRate(0.48);
    await tts.speak(text);
  }

  Future<void> _listen() async {
    if (listening) {
      await speech.stop();
      if (mounted) setState(() => listening = false);
      return;
    }

    final ok = await speech.initialize(
      onStatus: (status) {
        if (status == 'done' && mounted) setState(() => listening = false);
      },
      onError: (_) {
        if (mounted) setState(() => listening = false);
      },
    );

    if (!ok) {
      _snack('ما قدرت أوصل للميكروفون. تأكدي من صلاحية الميكروفون.');
      return;
    }

    setState(() => listening = true);
    await speech.listen(
      localeId: 'ar',
      onResult: (result) {
        setState(() => input.text = result.recognizedWords);
        input.selection = TextSelection.fromPosition(
          TextPosition(offset: input.text.length),
        );
      },
    );
  }

  Future<String> _askBackend(String text) async {
    if (backendUrl.contains('YOUR-BACKEND')) {
      return _localReply(text);
    }

    final response = await http.post(
      Uri.parse(backendUrl),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'message': text}),
    );

    if (response.statusCode != 200) {
      throw Exception('Backend error ${response.statusCode}');
    }

    final data = jsonDecode(response.body);
    return data['reply']?.toString() ?? 'ما وصلني رد واضح من الخادم.';
  }

  String _localReply(String text) {
    final t = text.toLowerCase();
    if (t.contains('مرحبا') || t.contains('هلا') || t.contains('hello')) {
      return 'أهلًا فيكي 💜 أنا نيلو! النسخة الحالية تجريبية، ولما نربط الخادم بالذكاء الاصطناعي بصير الحوار أذكى.';
    }
    if (t.contains('طبخ') || t.contains('وصفة')) {
      return 'أكيد 🍳 احكيلي اسم الأكلة أو المكونات الموجودة عندك، وبنرتب الخطوات.';
    }
    if (t.contains('دراسة') || t.contains('واجب')) {
      return 'تمام 📚 ابعتيلي السؤال أو صورة التمرين وبساعدك تفهميه وتحليه.';
    }
    if (t.contains('سيارة') || t.contains('سياره')) {
      return 'تمام 🚗 احكيلي شو المشكلة الظاهرة بالسيارة، مثل صوت أو لمبة تحذير، وبشرحلك بشكل آمن شو ممكن يعني.';
    }
    return 'وصلتني رسالتك 💜 أنا حاليًا بوضع التجربة. بعد ربط Backend حقيقي، نيلو رح يقدر يتعامل مع المحادثات بشكل أوسع.';
  }

  Future<void> _send() async {
    final text = input.text.trim();
    if (text.isEmpty || loading) return;

    setState(() {
      messages.add(ChatMessage(text, true));
      input.clear();
      loading = true;
    });
    await _saveMessages();
    _scrollDown();

    try {
      final reply = await _askBackend(text);
      if (!mounted) return;
      setState(() {
        messages.add(ChatMessage(reply, false));
        loading = false;
      });
      await _saveMessages();
      _scrollDown();
      await _speak(reply);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        messages.add(ChatMessage(
          'صار في مشكلة بالاتصال بالخادم. جرّبي لاحقًا أو خلي التطبيق على وضع التجربة.',
          false,
        ));
        loading = false;
      });
      await _saveMessages();
      _scrollDown();
    }
  }

  void _clearChat() async {
    setState(() {
      messages
        ..clear()
        ..add(ChatMessage('تم فتح محادثة جديدة 💜 شو بدك نعمل؟', false));
    });
    await _saveMessages();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(
          scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _snack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    speech.stop();
    tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Nilo AI 💜'),
          centerTitle: true,
          actions: [
            IconButton(
              tooltip: 'محادثة جديدة',
              onPressed: _clearChat,
              icon: const Icon(Icons.add_comment_outlined),
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'voice') {
                  setState(() => voiceReplies = !voiceReplies);
                  _snack(voiceReplies ? 'الردود الصوتية مفعّلة 🔊' : 'الردود الصوتية متوقفة');
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'voice',
                  child: Text(voiceReplies ? 'إيقاف الصوت' : 'تشغيل الصوت'),
                ),
              ],
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: scroll,
                padding: const EdgeInsets.all(14),
                itemCount: messages.length + (loading ? 1 : 0),
                itemBuilder: (_, i) {
                  if (loading && i == messages.length) {
                    return const Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.all(12),
                        child: CircularProgressIndicator(),
                      ),
                    );
                  }
                  final m = messages[i];
                  return Align(
                    alignment: m.fromUser
                        ? Alignment.centerLeft
                        : Alignment.centerRight,
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 340),
                      margin: const EdgeInsets.symmetric(vertical: 5),
                      padding: const EdgeInsets.all(13),
                      decoration: BoxDecoration(
                        color: m.fromUser
                            ? Theme.of(context).colorScheme.primaryContainer
                            : Theme.of(context).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Text(
                        m.text,
                        style: const TextStyle(fontSize: 16, height: 1.35),
                      ),
                    ),
                  );
                },
              ),
            ),
            if (speaking)
              const Padding(
                padding: EdgeInsets.only(bottom: 4),
                child: Text('نيلو عم يحكي 🔊'),
              ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
                child: Row(
                  children: [
                    IconButton.filledTonal(
                      onPressed: _listen,
                      icon: Icon(
                        listening ? Icons.stop : Icons.mic_none_rounded,
                      ),
                    ),
                    const SizedBox(width: 7),
                    Expanded(
                      child: TextField(
                        controller: input,
                        minLines: 1,
                        maxLines: 4,
                        textInputAction: TextInputAction.newline,
                        decoration: InputDecoration(
                          hintText: 'احكي لنيلو...',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(22),
                          ),
                        ),
                        onSubmitted: (_) => _send(),
                      ),
                    ),
                    const SizedBox(width: 7),
                    IconButton.filled(
                      onPressed: _send,
                      icon: const Icon(Icons.arrow_upward_rounded),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
