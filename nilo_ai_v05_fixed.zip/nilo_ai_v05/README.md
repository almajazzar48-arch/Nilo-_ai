# Nilo AI v0.5

واجهة Nilo AI الجديدة: تصميم داكن مستقبلي مع وهج بنفسجي/ذهبي، orb مركزي، أقسام المساعدة كشرائط زجاجية، محادثة، وإدخال صوتي.

هذه النسخة ما زالت Prototype:
- الذكاء الاصطناعي الحقيقي يحتاج Backend آمن.
- لا تضعي أي API key داخل التطبيق أو GitHub.
- ملف Android يمكن توليده عبر GitHub Actions كما في النسخة السابقة.

## Build
flutter pub get
flutter build apk --debug
