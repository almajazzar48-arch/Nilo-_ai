import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const NiloApp());

class NiloApp extends StatelessWidget {
  const NiloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Nilo AI',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'sans',
        scaffoldBackgroundColor: const Color(0xFF090612),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9B5CFF),
          brightness: Brightness.dark,
        ),
      ),
      home: const NiloHome(),
    );
  }
}

class ChatItem {
  final String text;
  final bool fromUser;
  ChatItem(this.text, this.fromUser);

  Map<String, dynamic> toJson() => {'text': text, 'fromUser': fromUser};
  factory ChatItem.fromJson(Map<String, dynamic> j) =>
      ChatItem(j['text'] ?? '', j['fromUser'] == true);
}

class NiloHome extends StatefulWidget {
  const NiloHome({super.key});

  @override
  State<NiloHome> createState() => _NiloHomeState();
}

class _NiloHomeState extends State<NiloHome> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  final List<ChatItem> _messages = [
    ChatItem('أهلاً! أنا نيلو 💜\nاحكيلي شو بدك، ومنمشي خطوة بخطوة.', false),
  ];

  bool _listening = false;
  bool _voiceReplies = true;
  bool _busy = false;

  // Later this will point to the secure backend that talks to the AI provider.
  static const String backendUrl = 'https://YOUR-BACKEND.example.com/chat';

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _tts.setSpeechRate(0.48);
  }

  Future<void> _loadMessages() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('nilo_messages');
    if (raw != null) {
      final decoded = (jsonDecode(raw) as List)
          .map((e) => ChatItem.fromJson(e))
          .toList();
      if (decoded.isNotEmpty && mounted) {
        setState(() {
          _messages
            ..clear()
            ..addAll(decoded);
        });
      }
    }
  }

  Future<void> _saveMessages() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
      'nilo_messages',
      jsonEncode(_messages.map((e) => e.toJson()).toList()),
    );
  }

  Future<void> _send(String value) async {
    final text = value.trim();
    if (text.isEmpty || _busy) return;

    _controller.clear();
    setState(() {
      _messages.add(ChatItem(text, true));
      _busy = true;
    });
    _saveMessages();
    _jumpBottom();

    String reply;
    try {
      final response = await http
          .post(
            Uri.parse(backendUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'message': text}),
          )
          .timeout(const Duration(seconds: 12));

      if (response.statusCode >= 200 && response.statusCode < 300) {
        final data = jsonDecode(response.body);
        reply = (data['reply'] ?? data['message'] ?? '').toString();
        if (reply.isEmpty) throw Exception('Empty reply');
      } else {
        throw Exception('Backend unavailable');
      }
    } catch (_) {
      reply = _localReply(text);
    }

    if (!mounted) return;
    setState(() {
      _messages.add(ChatItem(reply, false));
      _busy = false;
    });
    await _saveMessages();
    _jumpBottom();

    if (_voiceReplies) {
      await _tts.speak(reply);
    }
  }

  String _localReply(String text) {
    final t = text.toLowerCase();
    if (t.contains('مرحبا') || t.contains('اهلا') || t.contains('أهلا')) {
      return 'أهلاً فيكي 💜 أنا نيلو. النسخة الحالية تجريبية، ولسه رح نوصل الذكاء الاصطناعي الحقيقي.';
    }
    if (t.contains('مين') && t.contains('نيلو')) {
      return 'أنا نيلو 🤖💜 مساعدك الشخصي. هدفي أساعدك بالدراسة والتنظيم واللغات والمعلومات اليومية.';
    }
    return 'وصلتني رسالتك 💜 حالياً أنا بوضع التجربة، وبعد ربط الذكاء الاصطناعي رح أقدر جاوبك بشكل كامل.';
  }

  Future<void> _startListening() async {
    if (_listening) {
      await _speech.stop();
      setState(() => _listening = false);
      return;
    }

    final ok = await _speech.initialize();
    if (!ok) return;

    setState(() => _listening = true);
    await _speech.listen(
      localeId: 'ar',
      onResult: (result) {
        setState(() => _controller.text = result.recognizedWords);
        if (result.finalResult) {
          setState(() => _listening = false);
        }
      },
    );
  }

  void _newChat() async {
    setState(() {
      _messages
        ..clear()
        ..add(ChatItem('أهلاً! أنا نيلو 💜\nشو حابة نعمل اليوم؟', false));
    });
    await _saveMessages();
  }

  void _jumpBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Color(0xFF160C29),
                Color(0xFF0B0714),
                Color(0xFF090612),
              ],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                _topBar(),
                Expanded(
                  child: ListView(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 12),
                    children: [
                      _heroOrb(),
                      const SizedBox(height: 18),
                      _featureStrip(),
                      const SizedBox(height: 18),
                      ..._messages.map(_bubble),
                      if (_busy) _thinkingBubble(),
                    ],
                  ),
                ),
                _composer(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _topBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 6),
      child: Row(
        children: [
          _iconButton(Icons.more_vert, () {}),
          const Spacer(),
          const Text(
            'Nilo AI',
            style: TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.w800,
              letterSpacing: .2,
            ),
          ),
          const SizedBox(width: 10),
          const Text('💜', style: TextStyle(fontSize: 26)),
          const Spacer(),
          _iconButton(Icons.add_comment_outlined, _newChat),
        ],
      ),
    );
  }

  Widget _iconButton(IconData icon, VoidCallback onTap) {
    return Material(
      color: Colors.white.withOpacity(.06),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: Colors.white70),
        ),
      ),
    );
  }

  Widget _heroOrb() {
    return Center(
      child: Container(
        width: 154,
        height: 154,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const RadialGradient(
            colors: [
              Color(0xFFE5C56A),
              Color(0xFFB875FF),
              Color(0xFF4A2380),
              Color(0x00000000),
            ],
            stops: [0.0, .35, .72, 1.0],
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF9B5CFF).withOpacity(.38),
              blurRadius: 42,
              spreadRadius: 4,
            ),
          ],
        ),
        child: Center(
          child: Container(
            width: 92,
            height: 92,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(.25)),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF33204E), Color(0xFF120D1D)],
              ),
            ),
            child: const Center(
              child: Text(
                'Nilo',
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _featureStrip() {
    final features = [
      ['📚', 'دراسة'],
      ['⏰', 'تنظيم'],
      ['🌍', 'لغات'],
      ['🍳', 'طبخ'],
      ['🚗', 'سيارات'],
      ['🏠', 'بيت'],
      ['🐾', 'حيوانات'],
      ['📍', 'أماكن'],
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      reverse: true,
      child: Row(
        children: features.map((f) {
          return Container(
            margin: const EdgeInsets.only(left: 8),
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: Colors.white.withOpacity(.055),
              border: Border.all(color: Colors.white.withOpacity(.10)),
            ),
            child: Row(
              children: [
                Text(f[0], style: const TextStyle(fontSize: 17)),
                const SizedBox(width: 6),
                Text(
                  f[1],
                  style: const TextStyle(
                    color: Colors.white70,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _bubble(ChatItem item) {
    return Align(
      alignment: item.fromUser ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 355),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(24),
            topRight: const Radius.circular(24),
            bottomLeft: Radius.circular(item.fromUser ? 8 : 24),
            bottomRight: Radius.circular(item.fromUser ? 24 : 8),
          ),
          color: item.fromUser
              ? const Color(0xFF3A2460).withOpacity(.82)
              : Colors.white.withOpacity(.075),
          border: Border.all(color: Colors.white.withOpacity(.10)),
        ),
        child: Text(
          item.text,
          style: const TextStyle(
            fontSize: 17,
            height: 1.55,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _thinkingBubble() {
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: const Color(0xFF8D5CE8).withOpacity(.16),
          border: Border.all(color: Colors.white.withOpacity(.09)),
        ),
        child: const Text('نيلو عم يفكّر… ✨',
            style: TextStyle(color: Colors.white70, fontSize: 15)),
      ),
    );
  }

  Widget _composer() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Row(
        children: [
          Material(
            color: const Color(0xFF8060C7),
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: () => _send(_controller.text),
              child: const SizedBox(
                width: 54,
                height: 54,
                child: Icon(Icons.arrow_upward_rounded, size: 29),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.white.withOpacity(.045),
                border: Border.all(color: Colors.white.withOpacity(.18)),
              ),
              child: TextField(
                controller: _controller,
                textAlign: TextAlign.right,
                minLines: 1,
                maxLines: 4,
                style: const TextStyle(fontSize: 17, color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'احكي لنيلو…',
                  hintStyle: TextStyle(color: Colors.white54),
                  border: InputBorder.none,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                ),
                onSubmitted: _send,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Material(
            color: _listening
                ? const Color(0xFFD8B25C)
                : const Color(0xFFE7DDF7),
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: _startListening,
              child: SizedBox(
                width: 54,
                height: 54,
                child: Icon(
                  _listening ? Icons.stop_rounded : Icons.mic_none_rounded,
                  color: const Color(0xFF24152F),
                  size: 28,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
