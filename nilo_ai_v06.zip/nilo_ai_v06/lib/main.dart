import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const NiloApp());

class NiloApp extends StatelessWidget {
  const NiloApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Nilo',
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: const Color(0xFF05071C)),
    home: const NiloHome(),
  );
}

class VoicePreset {
  final String name, subtitle;
  final double rate, pitch;
  final IconData icon;
  const VoicePreset(this.name, this.subtitle, this.rate, this.pitch, this.icon);
}

const voices = [
  VoicePreset('هادئ', 'ناعم ومريح', .43, 1.02, Icons.nightlight_round),
  VoicePreset('مشرق', 'حيوي وواضح', .48, 1.12, Icons.auto_awesome_rounded),
  VoicePreset('دافئ', 'لطيف وقريب', .45, .96, Icons.favorite_rounded),
  VoicePreset('مستقبلي', 'ستايل AI واضح', .47, 1.18, Icons.smart_toy_rounded),
  VoicePreset('رسمي', 'للدراسة والمعلومات', .42, .90, Icons.school_rounded),
  VoicePreset('نشِط', 'سريع وحيوي', .55, 1.08, Icons.bolt_rounded),
];

class NiloHome extends StatefulWidget {
  const NiloHome({super.key});
  @override State<NiloHome> createState() => _NiloHomeState();
}

class _NiloHomeState extends State<NiloHome> {
  final tts = FlutterTts();
  final speech = stt.SpeechToText();
  final input = TextEditingController();
  int selectedVoice = 0;
  bool listening = false;

  final cats = const [
    ('المعرفة\nوالتعلم', Icons.menu_book_rounded, Color(0xFF9B7BFF)),
    ('الصحة\nوالعافية', Icons.favorite_rounded, Color(0xFFFF5FA8)),
    ('المهام\nوالإنتاجية', Icons.check_circle_rounded, Color(0xFF69E8C4)),
    ('الطبخ\nوالوصفات', Icons.restaurant_rounded, Color(0xFFFFA63D)),
    ('الموقع\nوالمواصلات', Icons.location_on_rounded, Color(0xFFB47CFF)),
    ('السفر\nوالسياحة', Icons.flight_takeoff_rounded, Color(0xFF59D9FF)),
    ('الرياضة\nواللياقة', Icons.fitness_center_rounded, Color(0xFF62E4D7)),
    ('المال\nوالاستثمار', Icons.account_balance_wallet_rounded, Color(0xFFFFD36B)),
  ];

  @override
  void initState() {
    super.initState();
    _loadVoice();
  }

  Future<void> _loadVoice() async {
    final p = await SharedPreferences.getInstance();
    setState(() => selectedVoice = p.getInt('nilo_voice') ?? 0);
  }

  Future<void> _saveVoice(int i) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('nilo_voice', i);
    setState(() => selectedVoice = i);
  }

  Future<void> speak(String text, {int? voice}) async {
    final v = voices[voice ?? selectedVoice];
    await tts.setLanguage('ar-SA');
    await tts.setSpeechRate(v.rate);
    await tts.setPitch(v.pitch);
    await tts.speak(text);
  }

  Future<void> mic() async {
    if (listening) {
      await speech.stop();
      setState(() => listening = false);
      return;
    }
    if (!await speech.initialize()) return;
    setState(() => listening = true);
    await speech.listen(localeId: 'ar_SA', onResult: (r) {
      setState(() => input.text = r.recognizedWords);
    });
  }

  void settings() => Navigator.push(context, MaterialPageRoute(
    builder: (_) => VoiceSettings(
      selected: selectedVoice,
      onSelect: (i) => _saveVoice(i),
      onSpeak: (i) => speak('مرحباً، أنا نيلو. هذا صوت ${voices[i].name}.'),
    ),
  ));

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: Stack(children: [
        const SpaceBg(),
        SafeArea(child: Column(children: [
          top(),
          Expanded(child: home()),
          bottom(),
        ])),
      ]),
    ),
  );

  Widget top() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
    child: Row(children: [
      IconButton(onPressed: () {}, icon: const Icon(Icons.menu_rounded, size: 29)),
      const Spacer(),
      Column(children: const [
        Text('Nilo ✦', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: Colors.white)),
        Text('مساعدك الذكي في كل شيء', style: TextStyle(fontSize: 12, color: Color(0xFFE7DFFF))),
      ]),
      const Spacer(),
      IconButton(onPressed: settings, icon: const Icon(Icons.settings_rounded, size: 27)),
    ]),
  );

  Widget home() => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 18),
    child: Column(children: [
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Expanded(child: glass(child: const Padding(
          padding: EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('مرحباً، أنا نيلو 👋', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 7),
            Text('مستعد دائماً لمساعدتك 💜', style: TextStyle(color: Color(0xFFE0D9FF), fontSize: 15)),
          ]),
        ))),
        const SizedBox(width: 10),
        Container(width: 104, height: 104, decoration: const BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [Color(0xFFE8F7FF), Color(0xFF6C4EFF), Color(0x00130B42)]),
          boxShadow: [BoxShadow(color: Color(0xAA765DFF), blurRadius: 28)],
        ), child: const Icon(Icons.smart_toy_rounded, size: 60, color: Color(0xFF07102C))),
      ]),
      const SizedBox(height: 12),
      GestureDetector(onTap: mic, child: glass(
        radius: 34,
        child: Padding(padding: const EdgeInsets.all(8), child: Row(children: [
          Container(width: 54, height: 54, decoration: const BoxDecoration(
            shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFF63D9FF), Color(0xFF8A5BFF)])),
            child: Icon(Icons.mic_rounded, size: 29),
          )),
          const SizedBox(width: 12),
          Expanded(child: Text(listening ? 'أسمعك الآن...' : 'تحدث معي...', style: const TextStyle(color: Color(0xFFDAD3FF), fontSize: 16))),
          const Icon(Icons.graphic_eq_rounded, color: Color(0xFFD8C9FF), size: 31),
        ]))),
      ),
      const SizedBox(height: 20),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: cats.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, mainAxisSpacing: 12, crossAxisSpacing: 9, childAspectRatio: .84),
        itemBuilder: (_, i) {
          final c = cats[i];
          return GestureDetector(
            onTap: () => speak('فتحت قسم ${c.$1.replaceAll('\n', ' ')}'),
            child: Container(
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: RadialGradient(colors: [c.$3, const Color(0xFF11133C)]),
                border: Border.all(color: c.$3.withOpacity(.7)),
                boxShadow: [BoxShadow(color: c.$3.withOpacity(.25), blurRadius: 18)]),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(c.$2, size: 28), const SizedBox(height: 4),
                Text(c.$1, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
              ]),
            ),
          );
        },
      ),
      const SizedBox(height: 18),
      glass(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
        const Icon(Icons.auto_awesome_rounded, color: Color(0xFFFFD36B), size: 27),
        const SizedBox(width: 10),
        const Expanded(child: Text('أفكارك تستحق خطة ✦\nدع نيلو يساعدك في تحقيقها', style: TextStyle(fontSize: 14, height: 1.45))),
        const Icon(Icons.chevron_left_rounded),
      ]))),
    ]),
  );

  Widget bottom() => Container(
    margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
    padding: const EdgeInsets.symmetric(vertical: 8),
    decoration: BoxDecoration(
      color: const Color(0xAA090C2D),
      borderRadius: BorderRadius.circular(26),
      border: Border.all(color: const Color(0xFF5E52B5).withOpacity(.55)),
    ),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: const [
      NavItem(Icons.home_rounded, 'الرئيسية', true),
      NavItem(Icons.chat_bubble_outline_rounded, 'المحادثات', false),
      NavItem(Icons.star_border_rounded, 'المفضلة', false),
      NavItem(Icons.grid_view_rounded, 'المزيد', false),
    ]),
  );

  Widget glass({required Widget child, double radius = 24}) => ClipRRect(
    borderRadius: BorderRadius.circular(radius),
    child: BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: const Color(0xFF8C78FF).withOpacity(.55)),
          gradient: const LinearGradient(colors: [Color(0x553C3CB8), Color(0x22201763)]),
          boxShadow: const [BoxShadow(color: Color(0x443F28C7), blurRadius: 25)],
        ),
        child: child,
      ),
    ),
  );
}

class VoiceSettings extends StatelessWidget {
  final int selected;
  final Future<void> Function(int) onSelect;
  final Future<void> Function(int) onSpeak;
  const VoiceSettings({super.key, required this.selected, required this.onSelect, required this.onSpeak});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: Stack(children: [
        const SpaceBg(),
        SafeArea(child: Column(children: [
          Padding(padding: const EdgeInsets.all(16), child: Row(children: [
            IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
            const Expanded(child: Text('صوت نيلو', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
            const SizedBox(width: 48),
          ])),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 22), child: Text(
            'اختاري الصوت اللي بتحبيه، وجربيه قبل ما تعتمديه.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFFD8D1FF), fontSize: 14),
          )),
          const SizedBox(height: 18),
          Expanded(child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            itemCount: voices.length,
            itemBuilder: (_, i) {
              final v = voices[i];
              final active = selected == i;
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: active ? const Color(0xFFFFD36B) : const Color(0xFF6558B8), width: active ? 1.6 : 1),
                  gradient: LinearGradient(colors: active
                    ? [const Color(0x664C3FC5), const Color(0x333D1E73)]
                    : [const Color(0x44302B86), const Color(0x221D164F)]),
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  leading: Container(width: 48, height: 48, decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [Color(0xFF7ADFFF), Color(0xFF895AFF)]),
                  ), child: Icon(v.icon, color: Colors.white)),
                  title: Text(v.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                  subtitle: Text(v.subtitle, style: const TextStyle(color: Color(0xFFC9C1F4))),
                  trailing: Wrap(spacing: 4, children: [
                    IconButton(onPressed: () => onSpeak(i), icon: const Icon(Icons.play_circle_fill_rounded, color: Color(0xFFB9A8FF), size: 30)),
                    Radio<int>(value: i, groupValue: selected, onChanged: (x) { if (x != null) onSelect(x); }),
                  ]),
                  onTap: () => onSelect(i),
                ),
              );
            },
          )),
        ])),
      ]),
    ),
  );
}

class NavItem extends StatelessWidget {
  final IconData icon; final String label; final bool active;
  const NavItem(this.icon, this.label, this.active, {super.key});
  @override Widget build(BuildContext context) => Column(children: [
    Icon(icon, color: active ? const Color(0xFFE7D7FF) : const Color(0xFF9690C0), size: 25),
    Text(label, style: TextStyle(fontSize: 10, color: active ? Colors.white : const Color(0xFF9B96C2))),
  ]);
}

class SpaceBg extends StatelessWidget {
  const SpaceBg({super.key});
  @override Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(
      gradient: RadialGradient(center: Alignment(0, -.25), radius: 1.15,
        colors: [Color(0xFF21145B), Color(0xFF0A1038), Color(0xFF040515)]),
    ),
    child: CustomPaint(painter: StarsPainter()),
  );
}

class StarsPainter extends CustomPainter {
  @override void paint(Canvas c, Size s) {
    final p = Paint()..style = PaintingStyle.fill;
    final pts = [
      Offset(s.width*.08,s.height*.10), Offset(s.width*.84,s.height*.13), Offset(s.width*.48,s.height*.22),
      Offset(s.width*.18,s.height*.42), Offset(s.width*.76,s.height*.51), Offset(s.width*.34,s.height*.67),
      Offset(s.width*.90,s.height*.78), Offset(s.width*.12,s.height*.88),
    ];
    for (final x in pts) {
      p.color = const Color(0x88C8B8FF);
      c.drawCircle(x, 1.6, p);
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
