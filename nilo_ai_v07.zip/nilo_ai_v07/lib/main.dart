
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const NiloApp());

const ink = Color(0xFF050507);
const panel = Color(0xB30C0A16);
const purple = Color(0xFF7D5CFF);
const blue = Color(0xFF54C8FF);
const gold = Color(0xFFFFD36A);

class NiloApp extends StatelessWidget {
  const NiloApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Nilo',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: ink,
      fontFamily: 'sans',
      useMaterial3: true,
    ),
    home: const NiloHome(),
  );
}

class VoicePreset {
  final String name, subtitle;
  final double rate, pitch;
  final IconData icon;
  const VoicePreset(this.name, this.subtitle, this.rate, this.pitch, this.icon);
}

const voices = <VoicePreset>[
  VoicePreset('هادئ', 'ناعم ومريح', .43, 1.02, Icons.nightlight_round),
  VoicePreset('مشرق', 'حيوي وواضح', .48, 1.10, Icons.auto_awesome_rounded),
  VoicePreset('دافئ', 'لطيف وقريب', .45, .96, Icons.wb_sunny_rounded),
  VoicePreset('مستقبلي', 'ستايل AI واضح', .47, 1.16, Icons.smart_toy_rounded),
  VoicePreset('رسمي', 'للدراسة والمعلومات', .42, .92, Icons.school_rounded),
  VoicePreset('نشِط', 'سريع وحيوي', .54, 1.07, Icons.bolt_rounded),
];

class NiloHome extends StatefulWidget {
  const NiloHome({super.key});
  @override State<NiloHome> createState() => _NiloHomeState();
}

class _NiloHomeState extends State<NiloHome> {
  final tts = FlutterTts();
  final speech = stt.SpeechToText();
  final input = TextEditingController();
  int voiceIndex = 0;
  bool listening = false;
  bool voiceReplies = true;
  int tab = 0;

  final categories = const <NiloCategory>[
    NiloCategory('دراسة', 'وتعلّم', Icons.menu_book_rounded, Color(0xFF9D7CFF)),
    NiloCategory('تنظيم', 'ومهام', Icons.calendar_month_rounded, Color(0xFF62DDBB)),
    NiloCategory('لغات', 'وترجمة', Icons.translate_rounded, Color(0xFF59CFFF)),
    NiloCategory('طبخ', 'ووصفات', Icons.restaurant_rounded, Color(0xFFFFA34A)),
    NiloCategory('سيارات', 'وصيانة', Icons.directions_car_rounded, Color(0xFFB995FF)),
    NiloCategory('البيت', 'وصيانة', Icons.home_repair_service_rounded, Color(0xFFFFCF69)),
    NiloCategory('حيوانات', 'وعناية', Icons.pets_rounded, Color(0xFFFF79B7)),
    NiloCategory('أماكن', 'وسفر', Icons.public_rounded, Color(0xFF5DD9FF)),
    NiloCategory('صحة', 'ومعلومات', Icons.favorite_rounded, Color(0xFFFF6D9E)),
    NiloCategory('نشاط', 'ورياضة', Icons.directions_run_rounded, Color(0xFF62E4D7)),
    NiloCategory('مال', 'وميزانية', Icons.account_balance_wallet_rounded, Color(0xFFFFD36A)),
    NiloCategory('قراءة', 'وقصص', Icons.auto_stories_rounded, Color(0xFFAF8BFF)),
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      voiceIndex = p.getInt('nilo_voice') ?? 0;
      voiceReplies = p.getBool('nilo_voice_replies') ?? true;
    });
  }

  Future<void> _saveVoice(int i) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('nilo_voice', i);
    if (mounted) setState(() => voiceIndex = i);
  }

  Future<void> speak(String text, {int? index}) async {
    final v = voices[index ?? voiceIndex];
    await tts.setLanguage('ar-SA');
    await tts.setSpeechRate(v.rate);
    await tts.setPitch(v.pitch);
    await tts.speak(text);
  }

  Future<void> toggleMic() async {
    if (listening) {
      await speech.stop();
      if (mounted) setState(() => listening = false);
      return;
    }
    final ok = await speech.initialize();
    if (!ok) return;
    if (mounted) setState(() => listening = true);
    await speech.listen(
      localeId: 'ar_SA',
      onResult: (r) {
        if (!mounted) return;
        setState(() => input.text = r.recognizedWords);
      },
    );
  }

  void openChat() => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => NiloChat(voiceIndex: voiceIndex, speak: speak)),
  );

  void openSettings() => Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => VoiceSettings(
        selected: voiceIndex,
        voiceReplies: voiceReplies,
        onSelect: _saveVoice,
        onToggleReplies: (v) async {
          final p = await SharedPreferences.getInstance();
          await p.setBool('nilo_voice_replies', v);
          if (mounted) setState(() => voiceReplies = v);
        },
        onSpeak: (i) => speak('مرحباً، أنا نيلو. هذا صوت ${voices[i].name}.', index: i),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      backgroundColor: ink,
      body: Stack(
        children: [
          const NiloBackground(),
          SafeArea(
            child: Column(
              children: [
                _topBar(),
                Expanded(child: tab == 1 ? NiloChat(voiceIndex: voiceIndex, speak: speak, embedded: true) : _home()),
                _bottomBar(),
              ],
            ),
          ),
        ],
      ),
    ),
  );

  Widget _topBar() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 8, 14, 2),
    child: Row(
      children: [
        _roundButton(Icons.menu_rounded, () {}),
        const Spacer(),
        Column(
          children: [
            ShaderMask(
              shaderCallback: (r) => const LinearGradient(colors: [Colors.white, Color(0xFFB8A6FF), gold]).createShader(r),
              child: const Text('NILO', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 4, color: Colors.white)),
            ),
            const Text('مساعدك الذكي', style: TextStyle(fontSize: 11, color: Color(0xFFBDB4D5))),
          ],
        ),
        const Spacer(),
        _roundButton(Icons.settings_rounded, openSettings),
      ],
    ),
  );

  Widget _home() => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(16, 6, 16, 18),
    child: Column(
      children: [
        const SizedBox(height: 4),
        _hero(),
        const SizedBox(height: 14),
        _voiceBar(),
        const SizedBox(height: 20),
        Row(
          children: [
            const Expanded(child: Text('ماذا تريدين من نيلو؟', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
            Text('كل شيء بمكان واحد', style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.55))),
          ],
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: categories.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4, mainAxisSpacing: 14, crossAxisSpacing: 10, childAspectRatio: .78,
          ),
          itemBuilder: (_, i) => _category(categories[i]),
        ),
        const SizedBox(height: 16),
        _quickCard(),
      ],
    ),
  );

  Widget _hero() => Container(
    height: 188,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(34),
      border: Border.all(color: const Color(0xFF765FE0).withOpacity(.42)),
      gradient: const LinearGradient(
        begin: Alignment.topRight, end: Alignment.bottomLeft,
        colors: [Color(0xCC151020), Color(0xAA090812), Color(0xEE040406)],
      ),
      boxShadow: const [BoxShadow(color: Color(0x551E0E5E), blurRadius: 35, spreadRadius: 4)],
    ),
    child: Stack(
      children: [
        Positioned(right: -20, top: -30, child: _orb(160)),
        Positioned(right: 26, top: 38, child: _robotFace(88)),
        Positioned(left: 22, top: 35, child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('مرحباً 👋', style: TextStyle(fontSize: 14, color: Colors.white.withOpacity(.65))),
            const SizedBox(height: 5),
            const Text('أنا نيلو.', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            const Text('فكّري بصوت عالي…', style: TextStyle(fontSize: 18, color: Color(0xFFE4DAFF), fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Text('اسألي، احكي، أو ابدئي من أحد الأقسام.',
              style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.62))),
          ],
        )),
        Positioned(left: 20, bottom: 14, child: Row(
          children: [
            _miniPill(Icons.auto_awesome_rounded, 'AI'),
            const SizedBox(width: 6),
            _miniPill(Icons.graphic_eq_rounded, 'صوت'),
            const SizedBox(width: 6),
            _miniPill(Icons.language_rounded, 'لغات'),
          ],
        )),
      ],
    ),
  );

  Widget _voiceBar() => GestureDetector(
    onTap: toggleMic,
    child: GlassPanel(
      radius: 30,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      child: Row(
        children: [
          Container(
            width: 54, height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [blue, purple]),
              boxShadow: const [BoxShadow(color: Color(0x6654C8FF), blurRadius: 18)],
            ),
            child: Icon(listening ? Icons.stop_rounded : Icons.mic_rounded, size: 28),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(listening ? 'نيلو عم يسمعك…' : 'احكي مع نيلو',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              Text(listening ? 'احكي براحتك' : 'اضغطي هون وابدئي الكلام',
                style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.55))),
            ]),
          ),
          const Icon(Icons.graphic_eq_rounded, color: Color(0xFFBFAEFF), size: 30),
        ],
      ),
    ),
  );

  Widget _category(NiloCategory c) => GestureDetector(
    onTap: () {
      speak('فتحت قسم ${c.title} ${c.subtitle}');
    },
    child: Column(
      children: [
        Expanded(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [c.color.withOpacity(.72), const Color(0xFF15121D)]),
              border: Border.all(color: c.color.withOpacity(.55)),
              boxShadow: [BoxShadow(color: c.color.withOpacity(.20), blurRadius: 20)],
            ),
            child: Icon(c.icon, size: 29),
          ),
        ),
        const SizedBox(height: 6),
        Text(c.title, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
        Text(c.subtitle, style: TextStyle(fontSize: 9.5, color: Colors.white.withOpacity(.5))),
      ],
    ),
  );

  Widget _quickCard() => GlassPanel(
    radius: 25,
    padding: const EdgeInsets.all(15),
    child: Row(
      children: [
        Container(width: 44, height: 44, decoration: const BoxDecoration(
          shape: BoxShape.circle, gradient: LinearGradient(colors: [gold, Color(0xFFB78A35)])),
          child: const Icon(Icons.auto_awesome_rounded, color: Color(0xFF241707)),
        )),
        const SizedBox(width: 11),
        const Expanded(child: Text('عندك فكرة أو مهمة؟\nنيلو بيساعدك ترتّبيها خطوة خطوة.',
          style: TextStyle(fontSize: 13, height: 1.4, fontWeight: FontWeight.w600))),
        IconButton(onPressed: openChat, icon: const Icon(Icons.arrow_back_rounded)),
      ],
    ),
  );

  Widget _bottomBar() => Container(
    margin: const EdgeInsets.fromLTRB(12, 0, 12, 9),
    padding: const EdgeInsets.symmetric(vertical: 9),
    decoration: BoxDecoration(
      color: const Color(0xD90A0910),
      borderRadius: BorderRadius.circular(27),
      border: Border.all(color: const Color(0xFF5D4C8F).withOpacity(.48)),
      boxShadow: const [BoxShadow(color: Color(0x44000000), blurRadius: 20)],
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        NavItem(Icons.home_rounded, 'الرئيسية', tab == 0, () => setState(() => tab = 0)),
        NavItem(Icons.chat_bubble_outline_rounded, 'المحادثة', tab == 1, () => setState(() => tab = 1)),
        NavItem(Icons.star_border_rounded, 'المفضلة', false, () {}),
        NavItem(Icons.settings_outlined, 'الإعدادات', false, openSettings),
      ],
    ),
  );

  Widget _roundButton(IconData icon, VoidCallback onTap) => Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 45, height: 45,
        decoration: BoxDecoration(
          color: const Color(0x5514111D),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF4D4266).withOpacity(.65)),
        ),
        child: Icon(icon, size: 22, color: Colors.white.withOpacity(.9)),
      ),
    ),
  );

  Widget _orb(double size) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: const RadialGradient(colors: [Color(0xFFF5F2FF), Color(0xFF8D70FF), Color(0xFF28135E), Color(0x00130A25)]),
      boxShadow: const [BoxShadow(color: Color(0xAA7656FF), blurRadius: 45, spreadRadius: 3)],
    ),
  );

  Widget _robotFace(double size) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: const Color(0xFFEEEAF6),
      border: Border.all(color: const Color(0xFFFFD36A), width: 2),
      boxShadow: const [BoxShadow(color: Color(0x99765CFF), blurRadius: 22)],
    ),
    child: const Center(child: Icon(Icons.smart_toy_rounded, size: 48, color: Color(0xFF191522))),
  );

  Widget _miniPill(IconData icon, String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(30),
      color: const Color(0x551C1529),
      border: Border.all(color: const Color(0xFF65537F).withOpacity(.5)),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 13, color: const Color(0xFFD8C9FF)),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 9.5)),
    ]),
  );
}

class NiloCategory {
  final String title, subtitle;
  final IconData icon;
  final Color color;
  const NiloCategory(this.title, this.subtitle, this.icon, this.color);
}

class NiloChat extends StatefulWidget {
  final int voiceIndex;
  final Future<void> Function(String, {int? index}) speak;
  final bool embedded;
  const NiloChat({super.key, required this.voiceIndex, required this.speak, this.embedded = false});
  @override State<NiloChat> createState() => _NiloChatState();
}

class _NiloChatState extends State<NiloChat> {
  final controller = TextEditingController();
  final messages = <Map<String, String>>[];
  final speech = stt.SpeechToText();
  bool listening = false;

  @override
  Widget build(BuildContext context) {
    final body = Column(
      children: [
        if (!widget.embedded)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
            child: Row(children: [
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_forward_rounded)),
              const Expanded(child: Text('محادثة نيلو', textAlign: TextAlign.center, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
              const SizedBox(width: 48),
            ]),
          ),
        Expanded(
          child: messages.isEmpty
            ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                _chatOrb(),
                const SizedBox(height: 15),
                const Text('احكيلي شو بدك…', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 5),
                Text('سؤال، دراسة، تنظيم، طبخ أو أي فكرة.', style: TextStyle(color: Colors.white.withOpacity(.55))),
              ]))
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                itemCount: messages.length,
                itemBuilder: (_, i) {
                  final m = messages[i];
                  final me = m['who'] == 'me';
                  return Align(
                    alignment: me ? Alignment.centerLeft : Alignment.centerRight,
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 310),
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(13),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(19),
                        color: me ? const Color(0xFF171322) : const Color(0x442E2461),
                        border: Border.all(color: me ? const Color(0xFF3A304A) : const Color(0xFF6753A5).withOpacity(.55)),
                      ),
                      child: Text(m['text'] ?? '', style: const TextStyle(fontSize: 14, height: 1.4)),
                    ),
                  );
                },
              ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 5, 12, 10),
          child: GlassPanel(
            radius: 28,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
            child: Row(children: [
              IconButton(onPressed: _listen, icon: Icon(listening ? Icons.stop_circle_rounded : Icons.mic_rounded, color: blue)),
              Expanded(child: TextField(
                controller: controller,
                textDirection: TextDirection.rtl,
                style: const TextStyle(fontSize: 14),
                decoration: const InputDecoration(hintText: 'اكتبي أو احكي مع نيلو…', border: InputBorder.none),
                onSubmitted: (_) => _send(),
              )),
              IconButton(onPressed: _send, icon: const Icon(Icons.arrow_upward_rounded, color: gold)),
            ]),
          ),
        ),
      ],
    );
    return Directionality(textDirection: TextDirection.rtl, child: body);
  }

  Widget _chatOrb() => Container(
    width: 100, height: 100,
    decoration: const BoxDecoration(
      shape: BoxShape.circle,
      gradient: RadialGradient(colors: [Colors.white, Color(0xFF9D7CFF), Color(0xFF24114C), Color(0x00100A18)]),
      boxShadow: [BoxShadow(color: Color(0xAA765CFF), blurRadius: 35)],
    ),
    child: const Icon(Icons.smart_toy_rounded, size: 46, color: Color(0xFF16111D)),
  );

  Future<void> _listen() async {
    if (listening) {
      await speech.stop();
      if (mounted) setState(() => listening = false);
      return;
    }
    if (!await speech.initialize()) return;
    if (mounted) setState(() => listening = true);
    await speech.listen(localeId: 'ar_SA', onResult: (r) {
      if (!mounted) return;
      setState(() => controller.text = r.recognizedWords);
    });
  }

  Future<void> _send() async {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      messages.add({'who': 'me', 'text': text});
      controller.clear();
    });
    final reply = _localReply(text);
    await Future<void>.delayed(const Duration(milliseconds: 250));
    if (!mounted) return;
    setState(() => messages.add({'who': 'nilo', 'text': reply}));
    await widget.speak(reply, index: widget.voiceIndex);
  }

  String _localReply(String text) {
    final q = text.toLowerCase();
    if (q.contains('مرحبا') || q.contains('هاي') || q.contains('hello')) {
      return 'أهلاً فيكي 💜 أنا نيلو. احكيلي شو بدك نعمل سوا.';
    }
    if (q.contains('دراسة') || q.contains('درس') || q.contains('واجب')) {
      return 'أكيد. ابعتيلي اسم الدرس أو السؤال، ومنمشي فيه خطوة خطوة.';
    }
    if (q.contains('طبخ') || q.contains('وصفة')) {
      return 'أكيد! قوليلي شو المكونات اللي عندك وبساعدك ترتّبي وصفة.';
    }
    if (q.contains('نيلو')) {
      return 'أنا نيلو، مساعدك الذكي. بقدر أساعدك بالمعلومات، الدراسة، التنظيم، اللغات وأشياء يومية كثيرة.';
    }
    return 'تمام 💜 فهمت عليك. هاد حالياً نموذج نيلو التجريبي، وبنربطه بالذكاء الاصطناعي الحقيقي من الخلفية بعد ما نثبت الواجهة.';
  }
}

class VoiceSettings extends StatelessWidget {
  final int selected;
  final bool voiceReplies;
  final Future<void> Function(int) onSelect;
  final Future<void> Function(bool) onToggleReplies;
  final Future<void> Function(int) onSpeak;
  const VoiceSettings({super.key, required this.selected, required this.voiceReplies, required this.onSelect, required this.onToggleReplies, required this.onSpeak});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      backgroundColor: ink,
      body: Stack(children: [
        const NiloBackground(),
        SafeArea(child: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(14, 8, 14, 12), child: Row(children: [
            IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_forward_rounded)),
            const Expanded(child: Text('صوت نيلو', textAlign: TextAlign.center, style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
            const SizedBox(width: 48),
          ])),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Text(
            'اختاري الصوت وجربيه قبل الاعتماد. الأصوات الحالية تستخدم صوت الهاتف.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white.withOpacity(.58), fontSize: 12.5),
          )),
          const SizedBox(height: 12),
          SwitchListTile(
            value: voiceReplies,
            onChanged: onToggleReplies,
            title: const Text('ردود نيلو الصوتية', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('تشغيل الرد بصوت بعد الرسالة'),
            activeColor: gold,
          ),
          Expanded(child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
            itemCount: voices.length,
            itemBuilder: (_, i) {
              final v = voices[i];
              final active = selected == i;
              return GlassPanel(
                radius: 21,
                margin: const EdgeInsets.only(bottom: 10),
                borderColor: active ? gold : const Color(0xFF4E4267),
                child: ListTile(
                  leading: Container(width: 46, height: 46, decoration: const BoxDecoration(
                    shape: BoxShape.circle, gradient: LinearGradient(colors: [blue, purple])),
                    child: Icon(v.icon)),
                  title: Text(v.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(v.subtitle, style: TextStyle(color: Colors.white.withOpacity(.55))),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(onPressed: () => onSpeak(i), icon: const Icon(Icons.play_circle_fill_rounded, color: gold, size: 30)),
                    Radio<int>(value: i, groupValue: selected, onChanged: (x) { if (x != null) onSelect(x); }),
                  ]),
                  onTap: () => onSelect(i),
                ),
              );
            },
          )),
        ])),
      ]),
    ),
  );
}

class GlassPanel extends StatelessWidget {
  final Widget child;
  final double radius;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final Color? borderColor;
  const GlassPanel({super.key, required this.child, this.radius = 24, this.padding = EdgeInsets.zero, this.margin, this.borderColor});

  @override
  Widget build(BuildContext context) => Container(
    margin: margin,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: borderColor ?? const Color(0xFF6C5A91).withOpacity(.48)),
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0x7A1D1827), Color(0x32110D18)]),
      boxShadow: const [BoxShadow(color: Color(0x30000000), blurRadius: 22)],
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Padding(padding: padding, child: child),
      ),
    ),
  );
}

class NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const NavItem(this.icon, this.label, this.active, this.onTap, {super.key});
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(20),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 7),
      child: Column(children: [
        Icon(icon, color: active ? gold : const Color(0xFF8D849D), size: 23),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(fontSize: 9.5, color: active ? Colors.white : const Color(0xFF8D849D))),
      ]),
    ),
  );
}

class _NiloBackground extends StatelessWidget {
  const _NiloBackground();
  @override
  Widget build(BuildContext context) => const NiloBackground();
}

class NiloBackground extends StatelessWidget {
  const NiloBackground({super.key});
  @override
  Widget build(BuildContext context) => CustomPaint(
    painter: NiloBackgroundPainter(),
    child: Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -.25), radius: 1.25,
          colors: [Color(0xFF1A112A), Color(0xFF090812), Color(0xFF030305)],
        ),
      ),
    ),
  );
}

class NiloBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..style = PaintingStyle.fill;
    final points = <Offset>[
      Offset(size.width*.08, size.height*.10), Offset(size.width*.87, size.height*.11),
      Offset(size.width*.30, size.height*.20), Offset(size.width*.73, size.height*.32),
      Offset(size.width*.13, size.height*.52), Offset(size.width*.91, size.height*.61),
      Offset(size.width*.43, size.height*.76), Offset(size.width*.18, size.height*.88),
    ];
    for (final pt in points) {
      p.color = const Color(0x777B6B9C);
      canvas.drawCircle(pt, 1.25, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
