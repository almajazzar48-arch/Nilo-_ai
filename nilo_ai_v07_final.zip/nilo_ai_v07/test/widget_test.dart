import 'package:flutter_test/flutter_test.dart';
import 'package:nilo_ai_v07/main.dart';

void main() {
  testWidgets('Nilo app starts', (tester) async {
    await tester.pumpWidget(const NiloApp());
    expect(find.text('نيلو'), findsWidgets);
  });
}
